/**
 *
 * @author joey
 */
public interface Position<E> {    
    public E getElement() throws IllegalStateException;
}
