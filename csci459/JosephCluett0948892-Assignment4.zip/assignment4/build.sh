gcc -o physical_wire physical_wire.c
gcc -o data_link_layer data_link_layer.c
gcc -o network_layer network_layer.c

