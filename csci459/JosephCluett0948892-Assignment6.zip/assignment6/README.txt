To compile the program:

	sh build.sh

This will generate a file called:

	main

Run the compiled executable with:
	
	./main

Add appropiate arguments as needed. A sample run might be:

	./main www.google.com /index.html 80

This will setup a TCP socket connection and read the entire response
and then print the entire thing to stdout

Project developed on platform with the following specifications:

Platform - Ubuntu Linux 16.04.5 (Desktop Edition)
Compiler - gcc 5.4.0
Kernel   - 4.4.0

Please direct any questions to
	joseph.cluett@ndsu.edu
			or
	joe.j.cluett@gmail.com
